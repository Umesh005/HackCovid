
import 'package:flutter/material.dart';

var subBackgroundColor = Color(0xFF253949);
var backgroundColor = Color(0xFF259ED9);


var topNavigationBackgroundColor = Color(0xFF1F4B6E);
var bottomNavigationBackgroundColor = Colors.greenAccent;


var bigTitleColor = Colors.greenAccent;
var titleColor = Colors.greenAccent;
var subTitleColor = Colors.greenAccent;
var descriptionColor = Colors.greenAccent;


var accpetButtonBackgroundColor = Colors.greenAccent;
var declineButtonBackgroundColor = Colors.greenAccent;
var pendingButtonBackgroundColor = Colors.greenAccent;


var activeButtonTextColor = Colors.white;
var inActiveButtonTextColor = Colors.black54;





var activeButtonBackgroundColor = Color(0xFF1F4B6E);
var inActiveButtonBackgroundColor = Colors.black12;
var removeButtonBackgroundColor = Colors.deepOrange;
